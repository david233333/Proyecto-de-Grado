package susalud.backend.persistencia.medicamentos.repositorio;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import susalud.backend.persistencia.medicamentos.entidad.MedsEntidad;

@Repository
public interface MedicamentosEntidadRepositorio extends JpaRepository<MedsEntidad, Serializable>
{

}
