package susalud.backend.persistencia.servicios.repositorio;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import susalud.backend.persistencia.servicios.entidad.ServiciosEntidad;

@Repository
public interface ServiciosEntidadRepositorio extends JpaRepository<ServiciosEntidad, Serializable>
{

}
