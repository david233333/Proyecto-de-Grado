package susalud.backend.rest.test;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import susalud.backend.dominio.medicamentos.dto.MedicamentosDto;
import susalud.backend.dominio.medicamentos.servicio.MedsServicio;
import susalud.backend.persistencia.medicamentos.entidad.MedsEntidad;

@CrossOrigin
@RestController
@RequestMapping("/api/meds")
public class MedicamentosRestController {

	@Autowired(required = true)
	private MedsServicio medsServicio;

	@GetMapping
	public List<MedsEntidad> obtenerMedicamentos() {
		return medsServicio.obtenerMedicamentos();
	}

	@PostMapping
	public void ingresarMedicamento(@Valid @RequestBody MedicamentosDto dto) {
		medsServicio.ingresarMedicamento(dto);
	}

	@DeleteMapping("/{idMed}")
	public void borrarMedicamentos(@PathVariable(value = "idMed") int idMed) {
		medsServicio.borrarMedicamento(idMed);
	}

	@PutMapping("/medicamento")
	public void editarMededicamento(@RequestBody MedicamentosDto dto) {
		medsServicio.editarMedicamento(dto);
	}
}
