package susalud.backend.rest.test;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import susalud.backend.dominio.servicios.dto.ServiciosDto;
import susalud.backend.dominio.servicios.servicio.SrvcServicio;
import susalud.backend.persistencia.servicios.entidad.ServiciosEntidad;

@CrossOrigin
@RestController
@RequestMapping("/api/servicios")
public class ServiciosRestController {
	
	@Autowired(required = true)
	private SrvcServicio srvcServicio;
	
	@GetMapping
	public List<ServiciosEntidad> obtenerServicios() {
		return srvcServicio.obtenerServicios();
	}
	
	@PostMapping
	public void ingresarServicio(@Valid @RequestBody ServiciosDto dto) {
		srvcServicio.ingresarServicio(dto);
	}
	
	@DeleteMapping("/{idServicio}")
	public void borrarMedicamentos(@PathVariable(value = "idServicio") int idServicio) {
		srvcServicio.borrarServicio(idServicio);
	}

	@PutMapping("/servicio")
	public void editarServicio(@RequestBody ServiciosDto dto) {
		srvcServicio.editarServicio(dto);
	}
}
