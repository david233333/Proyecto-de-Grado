package susalud.backend.dominio.medicamentos.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import susalud.backend.dominio.medicamentos.dto.MedicamentosDto;
import susalud.backend.dominio.medicamentos.servicio.MedsServicio;
import susalud.backend.persistencia.medicamentos.entidad.MedsEntidad;
import susalud.backend.persistencia.medicamentos.repositorio.MedicamentosEntidadRepositorio;

@Service
public class MedsServicioImpl implements MedsServicio {

	@Autowired
	private MedicamentosEntidadRepositorio medsEntidadRepositorio;

	@Override
	public void ingresarMedicamento(MedicamentosDto dto) {

		validarDto(dto);

		MedsEntidad meds = new MedsEntidad();
		meds.setCodigo(dto.getCodigo());
		meds.setNombre(dto.getNombreMedicamento());
		meds.setCantidad(dto.getCantidad());
		meds.setFechaIngreso(dto.getFechaIngreso());

		medsEntidadRepositorio.save(meds);

		System.out.println(dto);
	}

	private void validarDto(MedicamentosDto dto) {
		if (dto.getCodigo() != null) {
			System.out.println(dto.getCodigo());
		} else {
			System.out.println("Debes ingresar un c�digo");
		}
	}

	@Override
	public void borrarMedicamento(int idMed) {
		medsEntidadRepositorio.deleteById(idMed);
	}

	public void editarMedicamento(MedicamentosDto dto) {
		medsEntidadRepositorio.findById(dto.getId()).map(medicamentosEntidad -> {
			medicamentosEntidad.setCodigo(dto.getCodigo());
			medicamentosEntidad.setCantidad(dto.getCantidad());
			medicamentosEntidad.setNombre(dto.getNombreMedicamento());
			medicamentosEntidad.setFechaIngreso(dto.getFechaIngreso());
			return medsEntidadRepositorio.save(medicamentosEntidad);
		});
	}

	@Override
	public List<MedsEntidad> obtenerMedicamentos() {
		return medsEntidadRepositorio.findAll();
	}
}
