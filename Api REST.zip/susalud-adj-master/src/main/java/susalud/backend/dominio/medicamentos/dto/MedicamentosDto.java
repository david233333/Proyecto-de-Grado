package susalud.backend.dominio.medicamentos.dto;

import java.io.Serializable;
import java.sql.Date;

public class MedicamentosDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String nombreMedicamento;
	private Date fechaIngreso;
	private int cantidad;
	private String codigo;
	
	
	private int id;
	
	@Override
	public String toString() {
		return "Nombre medicamento: " + nombreMedicamento
			   + "\nC�digo: " + codigo
			   + "\nIngreso: " + fechaIngreso
			   + "\nCantidad: " + cantidad;	
	}
	
	public String getNombreMedicamento() {
		return nombreMedicamento;
	}
	public void setNombreMedicamento(String nombreMedicamento) {
		this.nombreMedicamento = nombreMedicamento;
	}
	public Date getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(Date fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
