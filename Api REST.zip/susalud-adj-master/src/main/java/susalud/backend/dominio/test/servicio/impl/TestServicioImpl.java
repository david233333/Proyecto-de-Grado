package susalud.backend.dominio.test.servicio.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import susalud.backend.dominio.test.dto.TestDto;
import susalud.backend.dominio.test.servicio.TestServicio;
import susalud.backend.persistencia.test.entidad.TestEntidad;
import susalud.backend.persistencia.test.repositorio.TestEntidadRepositorio;

@Service	
public class TestServicioImpl implements TestServicio{

	@Autowired
	private TestEntidadRepositorio testEntidadRepositorio;
	
	@Override
	public void ingresarTest(TestDto dto) {
		
		System.out.println("-------------------");
		
		validarNombre(dto);
		
		TestEntidad test = new TestEntidad();
		test.setNombre(dto.getNombre());
		
		testEntidadRepositorio.save(test);
		
		System.out.println(dto.getNombre());
	}

	private void validarNombre(TestDto dto) {
		if (dto.getNombre() != null) {
			System.out.println(dto.getNombre());
		} else {
			System.out.println("Debes ingresar un nombre");
		}
	}

	@Override
	public void borrarTest(int idTest) {
		testEntidadRepositorio.deleteById(idTest);
	}
}
