package susalud.backend.dominio.servicios.servicio;

import java.util.List;

import susalud.backend.dominio.servicios.dto.ServiciosDto;
import susalud.backend.persistencia.servicios.entidad.ServiciosEntidad;

public interface SrvcServicio {
	
	public void ingresarServicio(ServiciosDto dto);
	
	public void borrarServicio(int idServicio);

	public void editarServicio(ServiciosDto dto);

	public List<ServiciosEntidad> obtenerServicios();
}
