package susalud.backend.dominio.servicios.dto;

import java.io.Serializable;

public class ServiciosDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String nombreServicio;
	private String descripcion;
	
	private int id;
	
	@Override
	public String toString() {
		return "Nombre servicio: " + nombreServicio
			   + "\nDescripci�n: " + descripcion;
	}

	public String getNombreServicio() {
		return nombreServicio;
	}

	public void setNombreServicio(String nombreServicio) {
		this.nombreServicio = nombreServicio;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
