package susalud.backend.dominio.medicamentos.servicio;

import java.util.List;

import org.springframework.stereotype.Service;

import susalud.backend.dominio.medicamentos.dto.MedicamentosDto;
import susalud.backend.persistencia.medicamentos.entidad.MedsEntidad;

@Service
public interface MedsServicio {
		
	public void ingresarMedicamento(MedicamentosDto dto);
	
	public void borrarMedicamento(int idMed);

	public void editarMedicamento(MedicamentosDto dto);

	public List<MedsEntidad> obtenerMedicamentos();
}
