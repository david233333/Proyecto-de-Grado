package susalud.backend.dominio.servicios.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import susalud.backend.dominio.servicios.dto.ServiciosDto;
import susalud.backend.dominio.servicios.servicio.SrvcServicio;
import susalud.backend.persistencia.servicios.entidad.ServiciosEntidad;
import susalud.backend.persistencia.servicios.repositorio.ServiciosEntidadRepositorio;

@Service
public class ServicioImpl implements SrvcServicio {

	@Autowired
	private ServiciosEntidadRepositorio servicioEntidadRepositorio;
	
	@Override
	public void ingresarServicio(ServiciosDto dto) {
		
		ServiciosEntidad servicio = new ServiciosEntidad();
		servicio.setNombre(dto.getNombreServicio());
		servicio.setDescripcion(dto.getDescripcion());
		
		servicioEntidadRepositorio.save(servicio);
	}

	@Override
	public void borrarServicio(int idServicio) {
		servicioEntidadRepositorio.deleteById(idServicio);
	}

	@Override
	public void editarServicio(ServiciosDto dto) {
		servicioEntidadRepositorio.findById(dto.getId()).map(serviciosEntidad -> {
			serviciosEntidad.setNombre(dto.getNombreServicio());
			serviciosEntidad.setDescripcion(dto.getDescripcion());
			return servicioEntidadRepositorio.save(serviciosEntidad);
		});
	}

	@Override
	public List<ServiciosEntidad> obtenerServicios() {
		return servicioEntidadRepositorio.findAll();
	}
}
